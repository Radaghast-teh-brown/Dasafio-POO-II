
package javafx.layout;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

public class FXMLAnchorPaneAController implements Initializable {

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    @FXML
    public  void switchToB() throws IOException {
        Main.setRoot("/segunda/FXMLSegundaTela");
    }
    
}
